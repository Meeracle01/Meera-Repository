// App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home'; // Make sure the correct path to Home
import Login from './pages/Login'; // Make sure the correct path to Login
import SignUp from './pages/SignUp'; // Make sure the correct path to SignUp
import Region from './pages/Region'; // Make sure the Region page is imported

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} /> {/* Home page route */}
        <Route path="/login" element={<Login />} /> {/* Login page route */}
        <Route path="/signup" element={<SignUp />} /> {/* Sign up page route */}
        <Route path="/region/:regionName" element={<Region />} /> {/* Region page */}
      </Routes>
    </Router>
  );
}

export default App;

